package iia.games.base;

public interface IRole {
}

/*
example:

public enum RoleFake implements IRole{ WHITE, BLACK }

*/
