package iia.games.squadro;

import iia.games.base.IChallenger;

public class ChallengerSquadro implements IChallenger<MoveSquadro> {

    @Override
    public MoveSquadro pickMove(MoveSquadro enemyMove) {
        return null;
    }
}
