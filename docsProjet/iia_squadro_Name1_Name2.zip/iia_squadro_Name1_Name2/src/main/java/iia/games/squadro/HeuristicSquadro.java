package iia.games.squadro;

import iia.games.base.IHeuristic;

public class HeuristicSquadro  {


}
