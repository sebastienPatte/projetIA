package iia.games.squadro;


public class DuelSquadro {

    public static void main(String[] args) {
        System.out.println("Hello world !");

        System.out.println(" ======= GAME OVER =======");

    }

}
