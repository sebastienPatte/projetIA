package iia.games.base;

public interface IMove {
}

/*
example :
public class MoveFake{
    int x, y
}
*/