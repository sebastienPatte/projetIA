package iia.games.squadro;

import iia.games.base.IRole;

public enum RoleSquadro implements IRole {  }
