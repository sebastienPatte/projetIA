package iia.games.squadro;

import iia.games.base.IMove;

public class MoveSquadro implements IMove {

}
