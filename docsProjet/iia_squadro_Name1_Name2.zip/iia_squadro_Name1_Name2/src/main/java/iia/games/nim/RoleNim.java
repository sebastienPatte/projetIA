package iia.games.nim;

import iia.games.base.IRole;

public enum RoleNim implements IRole { FIRST, SECOND }

