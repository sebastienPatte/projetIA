package iia.espacesEtats.algorithmes;

import iia.espacesEtats.modeles.Probleme;
import iia.espacesEtats.modeles.Solution;

/**
 * RechercheEnLargeur codage de l'algorithme de recherche en largeur d'abord
 * 
 * @author <Vous Même>
 */
public class RechercheEnLargeur implements AlgorithmeRechercheEE {

    @Override
    public Solution chercheSolution(Probleme p) {
        // <A vous de compléter >
        return null;
    }
}
