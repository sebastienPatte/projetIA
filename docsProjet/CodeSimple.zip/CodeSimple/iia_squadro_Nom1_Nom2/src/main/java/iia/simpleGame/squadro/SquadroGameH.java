package iia.simpleGame.squadro;

public class SquadroGameH extends ASquadroGame {

    public SquadroGameH(){
        super();
    }

    @Override
    public int getValue(String role) {
        // TODO heuristic for Horizontal player
        return 0;
    }
}
