package iia.simpleGame.algo;

import iia.simpleGame.base.IGame;

public interface IAlgo {

    String bestMove(IGame game, String role);

}
