package iia.simpleGame.squadro;

public class PlaySquadro {
    public static void main(String[] args) {
        System.out.println("Hello world !");
    }
}
