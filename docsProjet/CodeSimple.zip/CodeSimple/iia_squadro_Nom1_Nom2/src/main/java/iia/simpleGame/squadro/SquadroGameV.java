package iia.simpleGame.squadro;

public class SquadroGameV extends ASquadroGame {

    public SquadroGameV(){
        super();
    }

    @Override
    public int getValue(String role) {
        // TODO heuristic for Vertical player
        return 0;
    }
}
