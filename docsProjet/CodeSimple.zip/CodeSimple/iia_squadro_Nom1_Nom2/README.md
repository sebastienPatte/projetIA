CHANGE PROJECT NAME IN settings.gradle file !

Build command :

gradle build

Test command : 

gradle test

Run Squadro :

gradle runSquadro

Run Squadro (approximative, change jar name):

java -cp  build/libs/Nom1_Nom2_iia-0.0.1.jar iia.simpleGame.squadro.PlaySquadro